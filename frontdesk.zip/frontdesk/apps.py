from django.apps import AppConfig


class FrontdeskConfig(AppConfig):
    name = 'frontdesk'
